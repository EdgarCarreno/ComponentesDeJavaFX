module reportes.ud05_reportes {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;      // OBLIGATORIO para WebView
    requires javafx.graphics; // OBLIGATORIO para el ciclo de vida de la App
    requires java.sql;
    requires net.sf.jasperreports.core;
    requires net.sf.jasperreports.pdf;
    requires org.apache.commons.logging;
    requires com.fasterxml.jackson.core;
    requires com.fasterxml.jackson.databind;
    requires com.fasterxml.jackson.dataformat.xml;
    requires org.xerial.sqlitejdbc;

    // Abrimos el paquete principal a fxml y web para que puedan cargar la interfaz y el motor HTML
    opens reportes.ud05_reportes to javafx.fxml, javafx.web, javafx.base, net.sf.jasperreports.core;
    opens reportes.ud05_reportes.beans to javafx.base, net.sf.jasperreports.core;

    exports reportes.ud05_reportes;
}


