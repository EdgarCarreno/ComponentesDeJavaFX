package reportes.ud05_reportes.beans;

/**
 * # Clase Detalle_factura
 * * Esta clase representa una línea individual de consumo dentro de una factura de luz.
 * Mapea directamente la tabla `DETALLE_FACTURA` de la base de datos SQLite.
 * * Cada instancia almacena el consumo realizado en un periodo horario específico
 * (tramo) y el coste aplicado por kilovatio hora.
 * * @author Edgar Carreño Castro
 * @version 1.0
 */
public class Detalle_factura {

    int id_detalle;
    int id_factura;
    String tramo;
    double consumo_kwh;
    double precio_kwh;

    /**
     * Constructor para instanciar el detalle de una factura.
     * * @param id_detalle Identificador único de la línea de detalle.
     * @param id_factura Identificador de la factura a la que pertenece este detalle (FK).
     * @param tramo Tipo de tramo horario: **punta**, **llano** o **valle**.
     * @param consumo_kwh Cantidad de energía consumida en ese tramo.
     * @param precio_kwh Precio unitario del kWh aplicado.
     */
    public Detalle_factura(int id_detalle, int id_factura, String tramo, double consumo_kwh, double precio_kwh) {
        this.id_detalle = id_detalle;
        this.id_factura = id_factura;
        this.tramo = tramo;
        this.consumo_kwh = consumo_kwh;
        this.precio_kwh = precio_kwh;
    }

    public int getId_detalle() {
        return id_detalle;
    }

    public void setId_detalle(int id_detalle) {
        this.id_detalle = id_detalle;
    }

    public int getId_factura() {
        return id_factura;
    }

    public void setId_factura(int id_factura) {
        this.id_factura = id_factura;
    }

    public String getTramo() {
        return tramo;
    }

    public void setTramo(String tramo) {
        this.tramo = tramo;
    }

    public double getConsumo_kwh() {
        return consumo_kwh;
    }

    public void setConsumo_kwh(double consumo_kwh) {
        this.consumo_kwh = consumo_kwh;
    }

    public double getPrecio_kwh() {
        return precio_kwh;
    }

    public void setPrecio_kwh(double precio_kwh) {
        this.precio_kwh = precio_kwh;
    }
}
