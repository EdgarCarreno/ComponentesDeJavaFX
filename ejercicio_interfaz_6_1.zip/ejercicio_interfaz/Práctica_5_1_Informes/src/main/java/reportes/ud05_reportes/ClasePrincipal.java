package reportes.ud05_reportes;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.util.Objects;

/**
 * # Clase ClasePrincipal
 * * Define el punto de entrada de la interfaz gráfica de usuario (GUI) utilizando **JavaFX**.
 * * Esta clase se encarga de:
 * - Cargar el archivo de diseño visual `hellofx.fxml`.
 * - Configurar el título y las dimensiones de la ventana principal.
 * - Desplegar el escenario (Stage) para que el usuario interactúe con ElectroFactura.
 * * @author Edgar Carreño Castro
 * @version 1.0
 */
public class ClasePrincipal extends Application {

    /**
     * Inicializa y muestra la ventana principal de la aplicación.
     * * @param primaryStage El escenario principal proporcionado por la plataforma JavaFX.
     * @throws Exception Si el archivo FXML no puede ser cargado o el recurso es nulo.
     */
    @Override
    public void start(Stage primaryStage) throws Exception{
        // Carga el diseño de la interfaz desde el archivo FXML
        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("hellofx.fxml")));

        // Configuración de la ventana principal
        primaryStage.setTitle("Uso de JasperReports");
        primaryStage.setScene(new Scene(root, 400, 300));

        // Muestra la interfaz al usuario
        primaryStage.show();
    }

    /**
     * Metodo main estándar que sirve como respaldo para lanzar la aplicación.
     * * @param args Argumentos de la línea de comandos.
     */
    public static void main(String[] args) {
        launch(args);
    }
}