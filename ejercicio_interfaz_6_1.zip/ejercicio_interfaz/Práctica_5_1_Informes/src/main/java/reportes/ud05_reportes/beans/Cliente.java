package reportes.ud05_reportes.beans;

/**
 * # Clase Cliente
 * * Representa la entidad de un cliente dentro del sistema ElectroFactura.
 * Esta clase actúa como un objeto de transferencia de datos (DTO) que mapea
 * directamente los registros de la tabla `CLIENTE` de la base de datos.
 * * Contiene la información básica de identificación y contacto necesaria para
 * la emisión de facturas legales.
 * * @author Edgar Carreño Castro
 * @version 1.0
 */
public class Cliente {

    int id_cliente;
    String nombre;
    String apellido;
    String nif;
    String direccion;

    /**
     * Constructor completo para crear una instancia de Cliente.
     * * @param id_cliente Identificador único generado por la base de datos (Clave primaria).
     * @param nombre Nombre de pila del cliente.
     * @param apellido Apellidos completos del cliente.
     * @param nif Número de Identificación Fiscal (DNI/NIE).
     * @param direccion Domicilio fiscal para el envío de facturas.
     */
    public Cliente(int id_cliente, String nombre, String apellido, String nif, String direccion) {
        this.id_cliente = id_cliente;
        this.nombre = nombre;
        this.apellido = apellido;
        this.nif = nif;
        this.direccion = direccion;
    }

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getNif() {
        return nif;
    }

    public void setNif(String nif) {
        this.nif = nif;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    /**
     * Devuelve una representación textual resumida del cliente.
     * Utilizada principalmente para mostrar información en los ComboBox de la interfaz.
     * * @return Cadena formateada con el ID y el Nombre del cliente.
     */
    @Override
    public String toString() {
        return "ID: " + this.id_cliente + " - " + this.nombre;
    }
}