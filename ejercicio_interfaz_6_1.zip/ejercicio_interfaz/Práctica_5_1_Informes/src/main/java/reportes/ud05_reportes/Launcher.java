package reportes.ud05_reportes;

import javafx.application.Application;

/**
 * # Clase Launcher
 * * Esta clase sirve como el punto de entrada principal (Main Entry Point) de la aplicación.
 * * Su única responsabilidad es llamar al metodo `launch` de la clase `ClasePrincipal` para
 * iniciar el entorno de ejecución de **JavaFX**.
 * * Separar el `main` en esta clase evita problemas comunes de compatibilidad con el
 * JavaFX Graphics Graph al ejecutar la aplicación desde un JAR.
 * * @author Edgar Carreño Castro
 * @version 1.0
 */
public class Launcher {

    /**
     * Metodo principal que arranca la máquina virtual de Java.
     * * @param args Argumentos de línea de comandos pasados al iniciar la aplicación.
     */
    public static void main(String[] args) {
        ClasePrincipal.launch(ClasePrincipal.class, args);
    }
}
