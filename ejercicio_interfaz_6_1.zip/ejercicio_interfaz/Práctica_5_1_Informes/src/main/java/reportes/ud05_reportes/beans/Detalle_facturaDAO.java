package reportes.ud05_reportes.beans;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * # Clase Detalle_facturaDAO
 * * Esta clase implementa el patrón **Data Access Object (DAO)** para la entidad `Detalle_factura`.
 * Se encarga de gestionar el desglose de consumos de cada factura en la tabla `detalle_factura`.
 * * Permite almacenar y consultar los consumos específicos por tramos horarios (punta, llano, valle).
 * * @author Edgar Carreño Castro
 * @version 1.0
 */
public class Detalle_facturaDAO {

    /**
     * Establece la conexión con la base de datos SQLite.
     * * @return Una instancia de `Connection` para acceder a `factura_luz.db`.
     * @throws SQLException Si hay un error en la ruta del archivo o en el motor SQLite.
     */
    private Connection getConnection() throws SQLException {
        return ConexionDB.configurar("jdbc:sqlite:DB/factura_luz.db").getConnection();
    }

    /**
     * Inserta una nueva línea de detalle de consumo en una factura.
     * * @param df Objeto `Detalle_factura` que contiene el ID de la factura, el tramo horario,
     * el consumo en kWh y el precio aplicado.
     */
    public void crear(Detalle_factura df) {
        String sql = "INSERT INTO DETALLE_FACTURA(id_factura, tramo, consumo_kwh, precio_kwh) VALUES(?,?,?,?)";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, df.getId_factura());
            pstmt.setString(2, df.getTramo());
            pstmt.setDouble(3, df.getConsumo_kwh());
            pstmt.setDouble(4, df.getPrecio_kwh());
            pstmt.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    /**
     * Recupera todas las líneas de detalle asociadas a una factura específica.
     * * @param idFactura Identificador de la factura de la cual se desea obtener el desglose.
     * @return Una `List<Detalle_factura>` con los tramos, consumos y precios registrados para esa factura.
     */
    public List<Detalle_factura> leerPorFactura(int idFactura) {
        List<Detalle_factura> lista = new ArrayList<>();
        String sql = "SELECT * FROM DETALLE_FACTURA WHERE id_factura = ?";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idFactura);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                lista.add(new Detalle_factura(rs.getInt("id_detalle"), rs.getInt("id_factura"),
                        rs.getString("tramo"), rs.getDouble("consumo_kwh"), rs.getDouble("precio_kwh")));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }

}
