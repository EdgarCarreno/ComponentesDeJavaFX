package reportes.ud05_reportes.beans;

import org.sqlite.SQLiteDataSource;
import javax.sql.DataSource;

public class ConexionDB
{
    private static SQLiteDataSource ds;

    public static DataSource configurar(String url) {
        ds = new SQLiteDataSource();
        ds.setUrl(url);
        return ds;
    }
}
