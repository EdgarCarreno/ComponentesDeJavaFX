package reportes.ud05_reportes.beans;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * # Clase ClienteDAO
 * * Esta clase implementa el patrón **Data Access Object (DAO)** para la entidad `Cliente`.
 * Se encarga de realizar todas las operaciones CRUD (Crear, Leer, Actualizar, Borrar)
 * [cite_start]directamente sobre la tabla `CLIENTE` en la base de datos SQLite[cite: 31, 33].
 * * @author Edgar Carreño Castro
 * @version 1.0
 */
public class ClienteDAO {

    /**
     * Establece la conexión con la base de datos local.
     * * [cite_start]@return Una instancia de `Connection` configurada para `factura_luz.db`[cite: 31].
     * @throws SQLException Si ocurre un error al acceder al archivo de la base de datos o la ruta es incorrecta.
     */
    private Connection getConnection() throws SQLException {
        return ConexionDB.configurar("jdbc:sqlite:DB/factura_luz.db").getConnection();
    }

    /**
     * Inserta un nuevo registro de cliente en la base de datos.
     * * [cite_start]@param c Objeto `Cliente` que contiene los datos a persistir: nombre, apellidos, nif y direccion[cite: 33].
     */
    public void crear(Cliente c) {
        String sql = "INSERT INTO CLIENTE(nombre, apellidos, nif, direccion) VALUES(?,?,?,?)";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, c.getNombre());
            pstmt.setString(2, c.getApellido());
            pstmt.setString(3, c.getNif());
            pstmt.setString(4, c.getDireccion());
            pstmt.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    /**
     * Recupera todos los clientes almacenados en la tabla `CLIENTE`.
     * * [cite_start]@return Una `List<Cliente>` con todos los registros encontrados (id, nombre, apellidos, nif y dirección)[cite: 33, 71].
     */
    public List<Cliente> leerTodos() {
        List<Cliente> lista = new ArrayList<>();
        String sql = "SELECT * FROM CLIENTE";
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new Cliente(rs.getInt("id_cliente"), rs.getString("nombre"),
                        rs.getString("apellidos"), rs.getString("nif"), rs.getString("direccion")));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }

    /**
     * Actualiza la información de un cliente existente basado en su ID único.
     * * [cite_start]@param c Objeto `Cliente` con los datos modificados y el `id_cliente` que actúa como clave primaria[cite: 33].
     */
    public void actualizar(Cliente c) {
        String sql = "UPDATE CLIENTE SET nombre=?, apellidos=?, nif=?, direccion=? WHERE id_cliente=?";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, c.getNombre());
            pstmt.setString(2, c.getApellido());
            pstmt.setString(3, c.getNif());
            pstmt.setString(4, c.getDireccion());
            pstmt.setInt(5, c.getId_cliente());
            pstmt.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

    /**
     * Elimina de forma permanente un cliente de la base de datos mediante su identificador.
     * * [cite_start]@param id El identificador único (`id_cliente`) del registro que se desea borrar[cite: 33].
     */
    public void eliminar(int id) {
        String sql = "DELETE FROM CLIENTE WHERE id_cliente = ?";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

}