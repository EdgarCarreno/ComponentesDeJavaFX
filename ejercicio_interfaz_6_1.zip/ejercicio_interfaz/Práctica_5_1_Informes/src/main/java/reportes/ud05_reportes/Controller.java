package reportes.ud05_reportes;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.view.JasperViewer;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import reportes.ud05_reportes.beans.*;

import java.io.InputStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

/**
 * # Clase Controller
 * * Esta clase es el controlador principal de la interfaz de usuario (JavaFX).
 * Gestiona la interacción del usuario, la manipulación de datos de clientes y la
 * generación de facturas eléctricas mediante **JasperReports**.
 * * ### Funcionalidades principales:
 * - Gestión CRUD de clientes en la interfaz.
 * - Carga de ayuda contextual mediante Tooltips y WebView.
 * - Generación de informes en formato PDF.
 * * @author Edgar Carreño Castro
 * @version 1.0
 */
public class Controller implements Initializable {

    private static final Log log = LogFactory.getLog(Controller.class);

    @FXML private TableView<Cliente> tablaClientes;
    @FXML private TableColumn<Cliente, Integer> colId;
    @FXML private TableColumn<Cliente, String> colNombre, colApellidos, colNif, colDireccion;
    @FXML private TextField txtNombre, txtApellidos, txtNif, txtDireccion;
    @FXML private Button btnGuardar, btnEliminar, btnGenerar;
    @FXML private ComboBox<Cliente> comboClientes;
    @FXML private DatePicker dpInicio, dpFin;
    @FXML private TextField txtPunta, txtLlano, txtValle;
    @FXML private Label labelStatus;
    @FXML private WebView webViewAyuda;

    private ClienteDAO clienteDAO = new ClienteDAO();
    private FacturaDAO facturaDAO = new FacturaDAO();
    private Detalle_facturaDAO detalleDAO = new Detalle_facturaDAO();

    /**
     * Inicializa los componentes de la interfaz al cargar el archivo FXML.
     * Configura las columnas de la tabla, los tooltips y la carga del manual de ayuda.
     */
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // 1. Columnas
        colId.setCellValueFactory(new PropertyValueFactory<>("id_cliente"));
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colApellidos.setCellValueFactory(new PropertyValueFactory<>("apellido"));
        colNif.setCellValueFactory(new PropertyValueFactory<>("nif"));
        colDireccion.setCellValueFactory(new PropertyValueFactory<>("direccion"));

        // 2. Tooltips (Ayuda Contextual)
        configurarTooltips();

        // 3. Ayuda HTML (WebView)
        cargarAyudaHtml();

        refrescarInterfaz();
    }

    /**
     * Configura la ayuda visual (Tooltips) para mejorar la experiencia de usuario (UX).
     */
    private void configurarTooltips() {
        tablaClientes.setTooltip(new Tooltip("Lista de clientes registrados"));
        txtNombre.setTooltip(new Tooltip("Nombre del cliente"));
        btnGuardar.setTooltip(new Tooltip("Guardar nuevo cliente en SQLite"));
        btnEliminar.setTooltip(new Tooltip("Eliminar cliente seleccionado"));
        btnGenerar.setTooltip(new Tooltip("Generar informe JasperReports y PDF"));
    }

    /**
     * Carga el archivo HTML de ayuda en el componente WebView.
     */
    private void cargarAyudaHtml() {
        try {
            WebEngine engine = webViewAyuda.getEngine();
            String url = getClass().getResource("/reportes/ud05_reportes/ayuda.html").toExternalForm();
            engine.load(url);
        } catch (Exception e) {
            log.error("Error al cargar ayuda: " + e.getMessage());
        }
    }

    /**
     * Actualiza la tabla de clientes y el desplegable con la información más reciente de la BD.
     */
    private void refrescarInterfaz() {
        try {
            ObservableList<Cliente> lista = FXCollections.observableArrayList(clienteDAO.leerTodos());
            tablaClientes.setItems(lista);
            comboClientes.setItems(lista);
        } catch (Exception e) {
            log.error("Error al refrescar tabla: " + e.getMessage());
        }
    }

    /**
     * Captura los datos de los campos de texto y registra un nuevo cliente.
     * @param event Evento de acción del botón guardar.
     */
    @FXML
    void guardarCliente(ActionEvent event) {
        if(txtNombre.getText().isEmpty()) return;
        Cliente nuevo = new Cliente(0, txtNombre.getText(), txtApellidos.getText(), txtNif.getText(), txtDireccion.getText());
        clienteDAO.crear(nuevo);
        refrescarInterfaz();
        limpiarCamposCliente();
    }

    /**
     * Elimina el cliente seleccionado en la tabla.
     * @param event Evento de acción del botón eliminar.
     */
    @FXML
    void eliminarCliente(ActionEvent event) {
        Cliente sel = tablaClientes.getSelectionModel().getSelectedItem();
        if (sel != null) {
            clienteDAO.eliminar(sel.getId_cliente());
            refrescarInterfaz();
        }
    }

    /**
     * Procesa la creación de una factura y sus detalles de consumo, iniciando la generación del informe.
     * @param event Evento de acción del botón generar factura.
     */
    @FXML
    void genPDF(ActionEvent event) {
        Cliente clienteSel = comboClientes.getSelectionModel().getSelectedItem();
        if (clienteSel == null || dpInicio.getValue() == null || dpFin.getValue() == null) {
            labelStatus.setText("Error: Datos incompletos.");
            return;
        }
        try {
            Factura f = new Factura(0, clienteSel.getId_cliente(), "2024-05-22",
                    dpInicio.getValue().toString(), dpFin.getValue().toString());
            int idFactura = facturaDAO.crear(f);

            detalleDAO.crear(new Detalle_factura(0, idFactura, "punta", Double.parseDouble(txtPunta.getText()), 0.22));
            detalleDAO.crear(new Detalle_factura(0, idFactura, "llano", Double.parseDouble(txtLlano.getText()), 0.15));
            detalleDAO.crear(new Detalle_factura(0, idFactura, "valle", Double.parseDouble(txtValle.getText()), 0.10));

            generarInforme(idFactura);
            labelStatus.setText("Factura " + idFactura + " generada.");
        } catch (Exception e) {
            labelStatus.setText("Error en proceso.");
        }
    }

    /**
     * Compila y genera el informe visual mediante **JasperReports**, exportándolo finalmente a PDF.
     * @param idFactura Identificador de la factura para filtrar el informe.
     */
    private void generarInforme(int idFactura) {
        String urlDB = "jdbc:sqlite:DB/factura_luz.db";
        try (Connection conn = DriverManager.getConnection(urlDB)) {
            Map<String, Object> parametros = new HashMap<>();
            parametros.put("ID_CLIENTE", idFactura);

            InputStream reportStream = getClass().getResourceAsStream("/reportes/ud05_reportes/Electricidad.jrxml");
            JasperReport jasperReport = JasperCompileManager.compileReport(reportStream);
            JasperPrint jp = JasperFillManager.fillReport(jasperReport, parametros, conn);

            JasperViewer.viewReport(jp, false);
            JasperExportManager.exportReportToPdfFile(jp, "Factura_" + idFactura + ".pdf");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Limpia los formularios de entrada de texto de la sección de clientes.
     */
    private void limpiarCamposCliente() {
        txtNombre.clear(); txtApellidos.clear(); txtNif.clear(); txtDireccion.clear();
    }
}