package reportes.ud05_reportes.beans;

/**
 * # Clase Factura
 * * Esta clase representa la cabecera de una factura eléctrica en el sistema.
 * Actúa como un objeto de datos que mapea la tabla `FACTURA` de SQLite.
 * * Contiene la información temporal del consumo y vincula la factura con un
 * cliente específico mediante su identificador.
 * * @author Edgar Carreño Castro
 * @version 1.0
 */
public class Factura {

    int id_factura;
    int id_cliente;
    String fecha_emision;
    String periodo_inicio;
    String periodo_fin;

    /**
     * Constructor para instanciar una Factura con todos sus datos.
     * * @param id_factura Código único de la factura.
     * @param id_cliente Identificador del cliente al que pertenece la factura (Clave ajena).
     * @param fecha_emision Fecha en la que se genera el documento.
     * @param periodo_inicio Fecha de inicio del periodo de lectura de consumo.
     * @param periodo_fin Fecha de fin del periodo de lectura de consumo.
     */
    public Factura(int id_factura, int id_cliente, String fecha_emision, String periodo_inicio, String periodo_fin) {
        this.id_factura = id_factura;
        this.id_cliente = id_cliente;
        this.fecha_emision = fecha_emision;
        this.periodo_inicio = periodo_inicio;
        this.periodo_fin = periodo_fin;
    }

    public int getId_factura() {
        return id_factura;
    }

    public void setId_factura(int id_factura) {
        this.id_factura = id_factura;
    }

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public String getFecha_emision() {
        return fecha_emision;
    }

    public void setFecha_emision(String fecha_emision) {
        this.fecha_emision = fecha_emision;
    }

    public String getPeriodo_inicio() {
        return periodo_inicio;
    }

    public void setPeriodo_inicio(String periodo_inicio) {
        this.periodo_inicio = periodo_inicio;
    }

    public String getPeriodo_fin() {
        return periodo_fin;
    }

    public void setPeriodo_fin(String periodo_fin) {
        this.periodo_fin = periodo_fin;
    }
}