package reportes.ud05_reportes.beans;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * # Clase FacturaDAO
 * * Esta clase implementa el patrón **Data Access Object (DAO)** para la entidad `Factura`.
 * Permite gestionar de forma persistente la cabecera de las facturas de luz en la tabla `FACTURA`.
 * * @author Edgar Carreño Castro
 * @version 1.0
 */
public class FacturaDAO {

    /**
     * Obtiene una conexión activa a la base de datos SQLite.
     * * @return Objeto `Connection` configurado para `factura_luz.db`.
     * @throws SQLException Si hay errores en la configuración del Driver o la ruta del archivo.
     */
    private Connection getConnection() throws SQLException {
        return ConexionDB.configurar("jdbc:sqlite:DB/factura_luz.db").getConnection();
    }

    /**
     * Registra una nueva factura en el sistema.
     * * @param f Objeto `Factura` con los datos de emisión y periodos de consumo. [cite: 32]
     * @return El ID generado para la nueva factura o -1 en caso de error.
     */
    public int crear(Factura f) {
        String sql = "INSERT INTO FACTURA(id_factura, id_cliente, fecha_emision, periodo_inicio, periodo_fin) VALUES(?,?,?,?,?)";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, f.getId_factura());
            pstmt.setInt(2, f.getId_cliente());
            pstmt.setString(3, f.getFecha_emision());
            pstmt.setString(4, f.getPeriodo_inicio());
            pstmt.setString(5, f.getPeriodo_fin());
            pstmt.executeUpdate();

            ResultSet rs = pstmt.getGeneratedKeys();
            return rs.next() ? rs.getInt(1) : -1;
        } catch (SQLException e) { e.printStackTrace(); return -1; }
    }

    /**
     * Consulta el historial de facturas vinculadas a un cliente específico.
     * * @param idCliente Identificador único del cliente en la tabla `CLIENTE`. [cite: 32, 33]
     * @return Una `List<Factura>` que contiene todas las facturas del cliente.
     */
    public List<Factura> obtenerPorCliente(int idCliente) {
        List<Factura> lista = new ArrayList<>();
        String sql = "SELECT * FROM FACTURA WHERE id_cliente = ?";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idCliente);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                lista.add(new Factura(rs.getInt("id_factura"), rs.getInt("id_cliente"),
                        rs.getString("fecha_emision"), rs.getString("periodo_inicio"), rs.getString("periodo_fin")));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return lista;
    }

    /**
     * Elimina una factura de la base de datos.
     * _Nota: Tenga en cuenta que esto puede afectar la integridad si existen detalles asociados._
     * * @param idFactura El ID de la factura a eliminar. [cite: 32]
     */
    public void eliminar(int idFactura) {
        String sql = "DELETE FROM FACTURA WHERE id_factura = ?";
        try (Connection conn = getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, idFactura);
            pstmt.executeUpdate();
        } catch (SQLException e) { e.printStackTrace(); }
    }

}