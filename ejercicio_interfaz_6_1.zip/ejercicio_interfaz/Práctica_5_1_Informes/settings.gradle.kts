rootProject.name = "Práctica_5_1_Informes"
