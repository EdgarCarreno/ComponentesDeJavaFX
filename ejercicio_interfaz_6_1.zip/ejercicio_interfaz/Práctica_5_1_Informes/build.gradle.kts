plugins {
    java
    application
    id("org.openjfx.javafxplugin") version "0.1.0"
}

group = "reportes"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

java {
    toolchain {
        languageVersion = JavaLanguageVersion.of(25)
    }
}

tasks.withType<JavaCompile> {
    options.encoding = "UTF-8"
}

application {
    mainModule.set("reportes.ud05_reportes")
    mainClass.set("reportes.ud05_reportes.Launcher") // Launcher suele ser mejor para evitar problemas de inicio
    this.applicationDefaultJvmArgs = listOf("--enable-native-access=javafx.graphics,org.xerial.sqlitejdbc")
}

javafx {
    // El plugin descargará las librerías automáticamente, no necesitas la ruta 'sdk'
    version = "21"
    // AGREGADO 'javafx.web' para cumplir con el punto del WebView solicitado
    modules = listOf("javafx.graphics", "javafx.controls", "javafx.fxml", "javafx.base", "javafx.web")
}

dependencies {
    // --- JASPERREPORTS 7 ---
    implementation("net.sf.jasperreports:jasperreports:7.0.3")
    implementation("net.sf.jasperreports:jasperreports-pdf:7.0.3")
    implementation("net.sf.jasperreports:jasperreports-jdt:7.0.3")

    // --- JACKSON ---
    implementation("com.fasterxml.jackson.core:jackson-databind:2.17.2")
    implementation("com.fasterxml.jackson.core:jackson-core:2.17.2")
    implementation("com.fasterxml.jackson.core:jackson-annotations:2.17.2")
    implementation("com.fasterxml.jackson.dataformat:jackson-dataformat-xml:2.17.2")
    implementation("net.sf.jasperreports:jasperreports-chart-customizers:7.0.3")

    // --- SQLITE & LOGGING ---
    implementation("org.xerial:sqlite-jdbc:3.45.3.0")
    implementation("commons-logging:commons-logging:1.3.1")

    // --- PDF ENGINE ---
    implementation("com.github.librepdf:openpdf:2.0.3")

    implementation("org.slf4j:slf4j-simple:2.0.9")
}
