module aplicacion {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires javafx.base;

    opens aplicacion to javafx.graphics, javafx.fxml;
    opens aplicacion.circulo to javafx.graphics, javafx.fxml;

    exports aplicacion;
    exports aplicacion.circulo;
}